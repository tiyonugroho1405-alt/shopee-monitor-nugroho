let TARGET = 15;
let data = JSON.parse(localStorage.getItem("shopeeData") || "[]");

function simpan(){
localStorage.setItem("shopeeData", JSON.stringify(data));
render();
}

function tambah(){
let produk = document.getElementById("produk").value;
let jam = document.getElementById("jam").value;

if(!produk || !jam){
alert("Isi produk dan jam dulu");
return;
}

data.push({
produk: produk,
jam: jam,
status: "Pending"
});

simpan();
}

function setStatus(index, status){
data[index].status = status;
simpan();
}

function render(){

let posted = data.filter(d=>d.status=="Posted").length;
let pending = data.filter(d=>d.status=="Pending").length;
let failed = data.filter(d=>d.status=="Failed").length;

let kurang = TARGET - posted;
let notif = "";

if(kurang > 0){
notif = "⚠ Kurang " + kurang + " video dari target";
}else{
notif = "🔥 Target tercapai atau melebihi";
}

document.getElementById("stats").innerHTML =
`
Posted: ${posted}<br>
Pending: ${pending}<br>
Failed: ${failed}<br>
${notif}
`;

let html = "";

data.forEach((d,i)=>{

html += `
<div class="card">
<b>${d.jam} - ${d.produk}</b><br>
Status: ${d.status}<br>

<button class="posted" onclick="setStatus(${i}, 'Posted')">Posted</button>
<button class="pending" onclick="setStatus(${i}, 'Pending')">Pending</button>
<button class="failed" onclick="setStatus(${i}, 'Failed')">Failed</button>
</div>
`;

});

document.getElementById("list").innerHTML = html;
}

render();
